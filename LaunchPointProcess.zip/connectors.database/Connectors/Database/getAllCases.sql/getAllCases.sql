SELECT caseid, clientid, batchid, environmentid FROM launchpointcase where active=true; 
